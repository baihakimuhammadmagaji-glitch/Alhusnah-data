import 'package:flutter/material.dart';

void main() {
  runApp(const AlHusnahApp());
}

class ApiService {
  static Future<Map<String, dynamic>> fetchWalletData(String token) async {
    await Future.delayed(const Duration(milliseconds: 300));
    return {
      'balance': 25480.00,
      'account_number': 'ALH12348',
    };
  }
}

class AlHusnahApp extends StatelessWidget {
  const AlHusnahApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ALHUSNAH DATA',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primaryColor: const Color(0xFF0D253F),
        scaffoldBackgroundColor: const Color(0xFF0F172A),
      ),
      home: const SplashScreen(),
    );
  }
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(seconds: 2), () {
      _showNotificationDialog();
    });
  }

  void _showNotificationDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: const [
            Icon(Icons.notifications_active, color: Colors.blue, size: 40),
            SizedBox(height: 15),
            Text(
              'Allow ALHUSNAH DATA to send notifications?',
              textAlign: TextAlign.center,
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              _goToOnboarding();
            },
            child: const Text('Don\'t allow'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF1E3A8A)),
            onPressed: () {
              Navigator.pop(context);
              _goToOnboarding();
            },
            child: const Text('Allow', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  void _goToOnboarding() {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => const OnboardingScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0B132B),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 80,
              height: 80,
              decoration: BoxDecoration(
                color: const Color(0xFF1E293B),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: Colors.amber.shade300, width: 2),
              ),
              child: Center(
                child: Text(
                  'A',
                  style: TextStyle(fontSize: 42, fontWeight: FontWeight.bold, color: Colors.amber.shade300),
                ),
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              'ALHUSNAH\nDATA',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold, letterSpacing: 1.5),
            ),
            const SizedBox(height: 10),
            const Text(
              'Data • Airtime • Bills • Wallet',
              style: TextStyle(color: Colors.white54, fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }
}

class OnboardingScreen extends StatelessWidget {
  const OnboardingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0B132B),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            children: [
              const Spacer(),
              Container(
                width: 70,
                height: 70,
                decoration: BoxDecoration(
                  color: Colors.amber.shade100,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Center(
                  child: Text('A', style: TextStyle(fontSize: 36, fontWeight: FontWeight.bold, color: Colors.blue.shade900)),
                ),
              ),
              const SizedBox(height: 15),
              const Text('ALHUSNAH DATA', style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)),
              const SizedBox(height: 20),
              Container(
                width: 140,
                height: 140,
                decoration: BoxDecoration(
                  color: const Color(0xFF1E293B),
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.blue.shade400, width: 2),
                ),
                child: const Icon(Icons.phone_android, size: 60, color: Colors.white70),
              ),
              const SizedBox(height: 30),
              const Text(
                'The fastest and most secure\nway to buy data, airtime,\npay bills and manage\nyour wallet.',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white70, fontSize: 14, height: 1.4),
              ),
              const Spacer(),
              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF2563EB),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  onPressed: () {
                    Navigator.push(context, MaterialPageRoute(builder: (context) => const LoginScreen()));
                  },
                  child: const Text('Get Started', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                ),
              ),
              const SizedBox(height: 12),
              TextButton(
                onPressed: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) => const LoginScreen()));
                },
                child: const Text('Login', style: TextStyle(color: Colors.white70)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0B132B),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: const BackButton(color: Colors.white),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Welcome Back', style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold)),
            const Text('Login to your account', style: TextStyle(color: Colors.white60, fontSize: 13)),
            const SizedBox(height: 25),
            const Text('Phone Number', style: TextStyle(color: Colors.white70, fontSize: 12)),
            const SizedBox(height: 8),
            TextField(
              style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(
                hintText: '080 1234 5678',
                hintStyle: const TextStyle(color: Colors.white38),
                filled: true,
                fillColor: const Color(0xFF1E293B),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none),
              ),
            ),
            const SizedBox(height: 16),
            const Text('Password', style: TextStyle(color: Colors.white70, fontSize: 12)),
            const SizedBox(height: 8),
            TextField(
              obscureText: true,
              style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(
                hintText: '••••••••',
                hintStyle: const TextStyle(color: Colors.white38),
                filled: true,
                fillColor: const Color(0xFF1E293B),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none),
              ),
            ),
            const SizedBox(height: 25),
            SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF2563EB), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
                onPressed: () {
                  Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => const PinVerificationScreen()));
                },
                child: const Text('Login', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
              ),
            ),
            const Spacer(),
            Center(
              child: TextButton(
                onPressed: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) => const RegisterScreen()));
                },
                child: const Text("Don't have an account? Register", style: TextStyle(color: Colors.blueAccent)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class RegisterScreen extends StatelessWidget {
  const RegisterScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0B132B),
      appBar: AppBar(backgroundColor: Colors.transparent, elevation: 0, leading: const BackButton(color: Colors.white)),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Create Account', style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold)),
            const Text('Fill in your details to get started', style: TextStyle(color: Colors.white60, fontSize: 13)),
            const SizedBox(height: 20),
            _buildDarkField('Full Name', 'Alhaji Muhammad'),
            _buildDarkField('Phone Number', '080 1234 5678'),
            _buildDarkField('Password', '••••••••', obscure: true),
            _buildDarkField('Confirm Password', '••••••••', obscure: true),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF2563EB), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
                onPressed: () {
                  Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => const PinVerificationScreen()));
                },
                child: const Text('Register', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDarkField(String label, String hint, {bool obscure = false}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(color: Colors.white70, fontSize: 12)),
          const SizedBox(height: 6),
          TextField(
            obscureText: obscure,
            style: const TextStyle(color: Colors.white),
            decoration: InputDecoration(
              hintText: hint,
              hintStyle: const TextStyle(color: Colors.white38),
              filled: true,
              fillColor: const Color(0xFF1E293B),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none),
            ),
          ),
        ],
      ),
    );
  }
}

class PinVerificationScreen extends StatelessWidget {
  const PinVerificationScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0B132B),
      appBar: AppBar(backgroundColor: Colors.transparent, elevation: 0),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: [
            const Text('Set 4-Digit PIN', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
            const Text('Create a PIN for quick access', style: TextStyle(color: Colors.white60, fontSize: 12)),
            const SizedBox(height: 30),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(4, (_) => Container(margin: const EdgeInsets.symmetric(horizontal: 10), width: 14, height: 14, decoration: const BoxDecoration(shape: BoxShape.circle, color: Colors.blueAccent))),
            ),
            const Spacer(),
            Expanded(
              flex: 3,
              child: GridView.count(
                crossAxisCount: 3,
                childAspectRatio: 1.5,
                children: [
                  ...List.generate(9, (index) => TextButton(onPressed: () {}, child: Text('${index + 1}', style: const TextStyle(fontSize: 24, color: Colors.white)))),
                  const SizedBox(),
                  TextButton(onPressed: () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => const HomeScreen())), child: const Text('0', style: TextStyle(fontSize: 24, color: Colors.white))),
                  IconButton(onPressed: () {}, icon: const Icon(Icons.backspace, color: Colors.white70)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentIndex = 2;

  final List<Widget> _screens = [
    const AirtimeScreen(),
    const TransactionHistoryScreen(),
    const HomeDashboardView(),
    const MoreServicesScreen(),
    const ProfileSettingsScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _screens[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        backgroundColor: const Color(0xFF0F172A),
        selectedItemColor: Colors.blueAccent,
        unselectedItemColor: Colors.white54,
        type: BottomNavigationBarType.fixed,
        onTap: (index) {
          setState(() {
            _currentIndex = index;
          });
        },
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.phone_android), label: 'Airtime'),
          BottomNavigationBarItem(icon: Icon(Icons.history), label: 'History'),
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.grid_view), label: 'More'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}

class HomeDashboardView extends StatelessWidget {
  const HomeDashboardView({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.fromLTRB(20, 50, 20, 25),
            color: const Color(0xFF1E3A8A),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('ALHUSNAH DATA', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
                    Row(
                      children: const [
                        Icon(Icons.wb_sunny, color: Colors.amber, size: 20),
                        SizedBox(width: 15),
                        Icon(Icons.notifications_none, color: Colors.white, size: 20),
                      ],
                    ),
                  ],
                ),
                const SizedBox(height: 15),
                const Text('Good morning,', style: TextStyle(color: Colors.white70, fontSize: 12)),
                const Text('Alhaji Muhammad', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 20),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(colors: [Color(0xFF2563EB), Color(0xFF1E40AF)]),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: FutureBuilder<Map<String, dynamic>>(
                    future: ApiService.fetchWalletData('DUMMY_TOKEN'),
                    builder: (context, snapshot) {
                      String balanceText = '₦25,480.00';
                      String accNumber = 'ALH12348';

                      if (snapshot.hasData && snapshot.data != null) {
                        final data = snapshot.data!;
                        balanceText = '₦${double.parse(data['balance'].toString()).toStringAsFixed(2)}';
                        accNumber = data['account_number'].toString();
                      }

                      return Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text('Wallet Balance', style: TextStyle(color: Colors.white70, fontSize: 12)),
                              Text(accNumber, style: const TextStyle(color: Colors.white70, fontSize: 12)),
                            ],
                          ),
                          const SizedBox(height: 10),
                          Text(balanceText, style: const TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.bold)),
                          const SizedBox(height: 15),
                          Align(
                            alignment: Alignment.centerRight,
                            child: ElevatedButton(
                              style: ElevatedButton.styleFrom(backgroundColor: Colors.amber.shade300, foregroundColor: Colors.black87),
                              onPressed: () {
                                _showGenericSheet(context, 'Fund Wallet Options');
                              },
                              child: const Text('Fund Wallet', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                            ),
                          ),
                        ],
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              children: [
                GridView.count(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  crossAxisCount: 4,
                  children: [
                    _gridItem(context, Icons.phone_android, 'Airtime', const AirtimeScreen()),
                    _gridItem(context, Icons.wifi, 'Data', const DataScreen()),
                    _gridItem(context, Icons.swap_horiz, 'Transfer', const TransferScreen()),
                    _gridItem(context, Icons.lightbulb, 'Electricity', const BillDetailScreen('Electricity Bills')),
                    _gridItem(context, Icons.tv, 'TV Cable', const BillDetailScreen('TV Cable Subscription')),
                    _gridItem(context, Icons.school, 'Exam Pin', const BillDetailScreen('Exam PIN Purchase')),
                    _gridItem(context, Icons.card_giftcard, 'Invite', const InviteScreen()),
                    _gridItem(context, Icons.apps, 'More', const MoreServicesScreen()),
                  ],
                ),
                const SizedBox(height: 20),
                const Align(
                  alignment: Alignment.centerLeft,
                  child: Text('Recent Transactions', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15)),
                ),
                const SizedBox(height: 10),
                _txTile('Airtime Purchase', '08012345678', '-₦500.00', Colors.redAccent),
                _txTile('Data Purchase', '10GB - 30 Days', '-₦2,000.00', Colors.redAccent),
                _txTile('Wallet Funded', 'Paystack', '+₦10,000.00', Colors.greenAccent),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _gridItem(BuildContext context, IconData icon, String label, Widget targetScreen) {
    return GestureDetector(
      onTap: () {
        Navigator.push(context, MaterialPageRoute(builder: (context) => targetScreen));
      },
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(color: const Color(0xFF1E293B), borderRadius: BorderRadius.circular(12)),
            child: Icon(icon, color: Colors.blueAccent, size: 24),
          ),
          const SizedBox(height: 6),
          Text(label, style: const TextStyle(color: Colors.white70, fontSize: 11)),
        ],
      ),
    );
  }

  Widget _txTile(String title, String subtitle, String amt, Color color) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: const Color(0xFF1E293B), borderRadius: BorderRadius.circular(10)),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13)),
            Text(subtitle, style: const TextStyle(color: Colors.white54, fontSize: 11)),
          ]),
          Text(amt, style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 13)),
        ],
      ),
    );
  }

  void _showGenericSheet(BuildContext context, String title) {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1E293B),
      builder: (_) => Container(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(title, style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 15),
            const Text('Moniepoint / OPay / Bank Transfer details go here.', style: TextStyle(color: Colors.white70)),
          ],
        ),
      ),
    );
  }
}

// AIRTIME SCREEN (Stateful)
class AirtimeScreen extends StatefulWidget {
  const AirtimeScreen({super.key});

  @override
  State<AirtimeScreen> createState() => _AirtimeScreenState();
}

class _AirtimeScreenState extends State<AirtimeScreen> {
  String selectedNetwork = 'MTN';
  final phoneController = TextEditingController();
  final amountController = TextEditingController();
  final networks = ['MTN', 'GLO', 'AIRTEL', '9MOBILE'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      appBar: AppBar(backgroundColor: const Color(0xFF1E3A8A), title: const Text('Buy Airtime', style: TextStyle(color: Colors.white))),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Select Network', style: TextStyle(color: Colors.white70, fontSize: 12)),
            const SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: networks.map((net) {
                final isSelected = selectedNetwork == net;
                return GestureDetector(
                  onTap: () => setState(() => selectedNetwork = net),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    decoration: BoxDecoration(
                      color: isSelected ? Colors.blueAccent : const Color(0xFF1E293B),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Text(net, style: TextStyle(color: Colors.white, fontWeight: isSelected ? FontWeight.bold : FontWeight.normal)),
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: 20),
            const Text('Phone Number', style: TextStyle(color: Colors.white70, fontSize: 12)),
            const SizedBox(height: 8),
            TextField(
              controller: phoneController,
              keyboardType: TextInputType.phone,
              style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(
                hintText: 'Enter Phone Number',
                hintStyle: const TextStyle(color: Colors.white54),
                filled: true,
                fillColor: const Color(0xFF1E293B),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none),
              ),
            ),
            const SizedBox(height: 20),
            const Text('Amount (₦)', style: TextStyle(color: Colors.white70, fontSize: 12)),
            const SizedBox(height: 8),
            TextField(
              controller: amountController,
              keyboardType: TextInputType.number,
              style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(
                hintText: '50 - 50,000',
                hintStyle: const TextStyle(color: Colors.white54),
                filled: true,
                fillColor: const Color(0xFF1E293B),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none),
              ),
            ),
            const SizedBox(height: 30),
            SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF2563EB), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
                onPressed: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Processing $selectedNetwork airtime of ₦${amountController.text}')),
                  );
                },
                child: const Text('Buy Airtime Now', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// DATA SCREEN (Stateful)
class DataScreen extends StatefulWidget {
  const DataScreen({super.key});

  @override
  State<DataScreen> createState() => _DataScreenState();
}

class _DataScreenState extends State<DataScreen> {
  String selectedNetwork = 'MTN';
  final phoneController = TextEditingController();
  String? selectedPlan;

  final dataPlans = {
    'MTN': ['1GB - 30 Days (₦300)', '2GB - 30 Days (₦600)', '5GB - 30 Days (₦1,500)'],
    'GLO': ['1GB - 14 Days (₦300)', '2.5GB - 30 Days (₦1,000)'],
    'AIRTEL': ['750MB - 14 Days (₦500)', '1.5GB - 30 Days (₦1,000)'],
    '9MOBILE': ['1GB - 30 Days (₦500)'],
  };

  @override
  Widget build(BuildContext context) {
    final plans = dataPlans[selectedNetwork] ?? [];
    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      appBar: AppBar(backgroundColor: const Color(0xFF1E3A8A), title: const Text('Buy Data Bundle', style: TextStyle(color: Colors.white))),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Select Network', style: TextStyle(color: Colors.white70, fontSize: 12)),
            const SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: ['MTN', 'GLO', 'AIRTEL', '9MOBILE'].map((net) {
                final isSelected = selectedNetwork == net;
                return GestureDetector(
                  onTap: () => setState(() {
                    selectedNetwork = net;
                    selectedPlan = null;
                  }),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                    decoration: BoxDecoration(
                      color: isSelected ? Colors.blueAccent : const Color(0xFF1E293B),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Text(net, style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: isSelected ? FontWeight.bold : FontWeight.normal)),
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: 20),
            const Text('Phone Number', style: TextStyle(color: Colors.white70, fontSize: 12)),
            const SizedBox(height: 8),
            TextField(
              controller: phoneController,
              keyboardType: TextInputType.phone,
              style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(
                hintText: 'Enter Phone Number',
                hintStyle: const TextStyle(color: Colors.white54),
                filled: true,
                fillColor: const Color(0xFF1E293B),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none),
              ),
            ),
            const SizedBox(height: 20),
            const Text('Select Data Plan', style: TextStyle(color: Colors.white70, fontSize: 12)),
            const SizedBox(height: 8),
            ...plans.map((plan) {
              final isSelected = selectedPlan == plan;
              return GestureDetector(
                onTap: () => setState(() => selectedPlan = plan),
                child: Container(
                  margin: const EdgeInsets.only(bottom: 10),
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: isSelected ? Colors.blueAccent.withOpacity(0.3) : const Color(0xFF1E293B),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: isSelected ? Colors.blueAccent : Colors.transparent),
                  ),
                  child: Text(plan, style: const TextStyle(color: Colors.white, fontSize: 14)),
                ),
              );
            }).toList(),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF2563EB), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
                onPressed: () {
                  if (selectedPlan == null) {
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Please select a data plan')));
                    return;
                  }
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Purchasing $selectedPlan for ${phoneController.text}')),
                  );
                },
                child: const Text('Buy Data', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// OTHER SUPPORTING SCREENS
class TransferScreen extends StatelessWidget {
  const TransferScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      appBar: AppBar(backgroundColor: const Color(0xFF1E3A8A), title: const Text('Transfer', style: TextStyle(color: Colors.white))),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: const [
            TextField(style: TextStyle(color: Colors.white), decoration: InputDecoration(hintText: 'Recipient User ID / Account Number', hintStyle: TextStyle(color: Colors.white54), filled: true, fillColor: Color(0xFF1E293B))),
          ],
        ),
      ),
    );
  }
}

class BillDetailScreen extends StatelessWidget {
  final String title;
  const BillDetailScreen(this.title, {super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      appBar: AppBar(backgroundColor: const Color(0xFF1E3A8A), title: Text(title, style: const TextStyle(color: Colors.white))),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            TextField(style: const TextStyle(color: Colors.white), decoration: InputDecoration(hintText: 'Enter SmartCard / Meter Number', hintStyle: TextStyle(color: Colors.white54), filled: true, fillColor: Color(0xFF1E293B))),
          ],
        ),
      ),
    );
  }
}

class InviteScreen extends StatelessWidget {
  const InviteScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      appBar: AppBar(backgroundColor: const Color(0xFF1E3A8A), title: const Text('Invite & Earn', style: TextStyle(color: Colors.white))),
      body: const Center(child: Text('Your Referral Code: ALH12348', style: TextStyle(color: Colors.white, fontSize: 16))),
    );
  }
}

class TransactionHistoryScreen extends StatelessWidget {
  const TransactionHistoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      appBar: AppBar(backgroundColor: const Color(0xFF1E3A8A), title: const Text('Transaction History', style: TextStyle(color: Colors.white))),
      body: const Center(child: Text('All transactions list here', style: TextStyle(color: Colors.white70))),
    );
  }
}

class MoreServicesScreen extends StatelessWidget {
  const MoreServicesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      appBar: AppBar(backgroundColor: const Color(0xFF1E3A8A), title: const Text('More Services', style: TextStyle(color: Colors.white))),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: GridView.count(
          crossAxisCount: 2,
          childAspectRatio: 3,
          children: const [
            Card(color: Color(0xFF1E293B), child: Center(child: Text('Data Bundles', style: TextStyle(color: Colors.white)))),
            Card(color: Color(0xFF1E293B), child: Center(child: Text('TV Sub', style: TextStyle(color: Colors.white)))),
            Card(color: Color(0xFF1E293B), child: Center(child: Text('Electricity', style: TextStyle(color: Colors.white)))),
            Card(color: Color(0xFF1E293B), child: Center(child: Text('Bulk SMS', style: TextStyle(color: Colors.white)))),
          ],
        ),
      ),
    );
  }
}

class ProfileSettingsScreen extends StatelessWidget {
  const ProfileSettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      appBar: AppBar(backgroundColor: const Color(0xFF1E3A8A), title: const Text('Profile / Settings', style: TextStyle(color: Colors.white))),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: const [
          CircleAvatar(radius: 40, backgroundColor: Colors.blueAccent, child: Text('AM', style: TextStyle(color: Colors.white, fontSize: 24))),
          SizedBox(height: 15),
          Center(child: Text('Alhaji Muhammad', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold))),
          Center(child: Text('ALH12348 • 08012345678', style: TextStyle(color: Colors.white54, fontSize: 12))),
          SizedBox(height: 25),
          ListTile(tileColor: Color(0xFF1E293B), leading: Icon(Icons.security, color: Colors.white), title: Text('KYC Verification', style: TextStyle(color: Colors.white))),
          SizedBox(height: 10),
          ListTile(tileColor: Color(0xFF1E293B), leading: Icon(Icons.lock, color: Colors.white), title: Text('PIN & Biometrics', style: TextStyle(color: Colors.white))),
          SizedBox(height: 10),
          ListTile(tileColor: Color(0xFF1E293B), leading: Icon(Icons.support_agent, color: Colors.white), title: Text('Help & Support', style: TextStyle(color: Colors.white))),
        ],
      ),
    );
  }
}
